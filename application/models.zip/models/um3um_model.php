



<?php



/*

 * To change this license header, choose License Headers in Project Properties.

 * To change this template file, choose Tools | Templates

 * and open the template in the editor.

 */



class um3um_model extends CI_Model {



    public function getall() {



        $this->db->group_by('competencia');

        $query = $this->db->get('dados_131');

        return $query->result();
 
    }



    public function getalldetalhe($competencia) {

        $this->db->where('competencia', $competencia);



        $query = $this->db->get('dados_131');

        return $query->result();

    }



    public function getid($id, $tipo) {



        if ($tipo == "RECEITA") {

            $this->db->where('cod_dados_131', $id);



            $query = $this->db->get('131_receita_dados');

        }

        if ($tipo == "DESPESA") {

            $this->db->where('cod_dados_131', $id);



            $query = $this->db->get('131_despesa_dados');

        }







        return $query->result();

    }


    
    function CountAll() {

        return $this->db->count_all("131_receita_dados");

    }

    function geDespesasPortal($sort = 'id', $order = 'desc', $limit = null, $offset = null) {

        $this->db->order_by($sort, $order);

        if ($limit)

            $this->db->limit($limit, $offset);



        $query = $this->db->get("131_despesa_dados");



        if ($query->num_rows() > 0) {



            return $query->result();

        } else {



            return null;

        }

    }

    public function getTipos($tipo) {



        if ($tipo == "RECEITA") {

          

            $query = $this->db->get('131_receita_dados');

        }

        if ($tipo == "DESPESA") {
            $this->db->where('tipo', 'PAG');
        

            $query = $this->db->get('131_despesa_dados');

        }







        return $query->result();

    }



}

?>